/*
 * $Id: in_cksum.h,v 1.1.1.8 2007/05/09 20:42:05 sachin Exp $
 *
 * INET Checksum from ping.c
 */

#ifndef AMT_LIBSUM_IN_CKSUM_H
#define AMT_LIBSUM_IN_CKSUM_H

u_short in_cksum(u_short*, int);

#endif  // AMT_LIBSUM_IN_CKSUM_H
