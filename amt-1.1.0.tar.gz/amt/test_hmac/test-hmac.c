
static const char __attribute__((unused)) id[] =
      "@(#) $Id: test-hmac.c,v 1.1.1.8 2007/05/09 20:42:23 sachin Exp $";

#include <stddef.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>

int
main(void)
{
    return 0;
}
